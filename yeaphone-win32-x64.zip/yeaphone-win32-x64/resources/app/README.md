
 ![YeaPhoneCaller](https://raw.githubusercontent.com/msohns/YeaPhoneCaller/master/icon.ico)

# YeaPhoneCaller
Controll your Yealink SIP IP Phones 

## What is it for
YeaPhone Caller Client is a small electron app to interact with your YeaLink IP Phones that are connected to as SIP PBX. 

## Keyboard Shortcuts
Answer a call **CTRLorCOMMAND + J**

Dial a Number from Clipboar **CTRLorCOMMAND + Y**

Mute the Phone **CTRLorCOMMAND + M**

## Tested Phones
YeaPhone Caller has been tested with these devices
* 27G
